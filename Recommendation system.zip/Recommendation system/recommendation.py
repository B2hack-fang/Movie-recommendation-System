import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load dataset
movies = pd.read_csv("movies.csv")

# Create lowercase title column (ONLY ONCE here)
movies["title_lower"] = movies["title"].str.lower()

# Combine features
movies["combined"] = movies["genre"] + " " + movies["keywords"]

# TF-IDF
tfidf = TfidfVectorizer(stop_words="english")
tfidf_matrix = tfidf.fit_transform(movies["combined"])

# Similarity matrix
similarity = cosine_similarity(tfidf_matrix)


def recommend(movie_name):
    movie_name = movie_name.lower().strip()

    if movie_name not in movies["title_lower"].values:
        return ["Movie not found"]

    movie_index = movies[movies["title_lower"] == movie_name].index[0]
    distances = similarity[movie_index]

    movie_list = sorted(
        list(enumerate(distances)),
        key=lambda x: x[1],
        reverse=True
    )

    recommendations = []
    for i in movie_list:
        if i[0] != movie_index and i[1] > 0:
            recommendations.append(movies.iloc[i[0]].title)
        if len(recommendations) == 5:
            break

    return recommendations
